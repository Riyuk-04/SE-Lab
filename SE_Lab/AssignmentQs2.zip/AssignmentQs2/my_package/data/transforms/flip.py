#Imports
from PIL import Image
import numpy as np

class FlipImage(object):
    '''
        Flips the image.
    '''

    def __init__(self, flip_type='horizontal'):
        '''
            Arguments:
            flip_type: 'horizontal' or 'vertical' Default: 'horizontal'
        '''

        # Write your code here
        self.flip_type = flip_type

        
    def __call__(self, image):
        '''
            Arguments:
            image (numpy array or PIL image)

            Returns:
            image (numpy array or PIL image)
        '''

        # Write your code here
        img = Image.fromarray(image)
        if self.flip_type == 'horizontal':
            self.image_flip = img.transpose(Image.FLIP_LEFT_RIGHT)
        elif self.flip_type == 'vertical':
            self.image_flip = img.transpose(Image.FLIP_TOP_BOTTOM)
        else :
            print(self.flip_type + " is not a valid input!!!")
            self.image_flip = img
        self.arr = np.asarray(self.image_flip)
        return self.arr
