#Imports
from PIL import Image
import numpy as np
from my_package.data.transforms import FlipImage,RescaleImage,BlurImage,CropImage,RotateImage

class Dataset(object):
    '''
        A class for the dataset that will return data items as per the given index
    '''

    def __init__(self, annotation_file, transforms = None):
        '''
            Arguments:
            annotation_file: path to the annotation file
            transforms: list of transforms (class instances)
                        For instance, [<class 'RandomCrop'>, <class 'Rotate'>]
        '''
        self.annotation_file = annotation_file
        self.transforms = transforms
        

    def __len__(self):
        '''
            return the number of data points in the dataset
        '''
        with open(self.annotation_file,'r') as f:
            json_list=list(f)
        return len(json_list)

    def __getitem__(self, idx):
        '''
            return the dataset element for the index: "idx"
            Arguments:
                idx: index of the data element.

            Returns: A dictionary with:
                image: image (in the form of a numpy array) (shape: (3, H, W))
                gt_bboxes: N X 5 array where N is the number of bounding boxes, each 
                            consisting of [class, x1, y1, x2, y2]
                            x1 and x2 lie between 0 and width of the image,
                            y1 and y2 lie between 0 and height of the image.

            You need to do the following, 
            1. Extract the correct annotation using the idx provided.
            2. Read the image and convert it into a numpy array (wont be necessary
                with some libraries). The shape of the array would be (3, H, W).
            3. Scale the values in the array to be with [0, 1].
            4. Create a dictonary with both the image and annotations
            4. Perform the desired transformations.
            5. Return the transformed image and annotations as specified.
        '''

        with open(self.annotation_file,'r') as f:
            json_list = list(f)
        
        annot = json_list[idx]
        annot_dict = eval(annot)
        image = Image.open("data/" + annot_dict['img_fn'])
        image_np = np.asarray(image)
        if self.transforms != None:
            for transforms in self.transforms:
                image_np = transforms(image_np)
        image_np = np.transpose(image_np,(2,0,1))
        image_np = image_np.astype('float32')
        image_np = image_np/255

        images_dict = dict()
        images_dict['image'] = image_np

        images_dict['gt_bboxes'] = []
        images_dict['gt_category'] = []
        for x in annot_dict['bboxes']:
          boxes = []
          images_dict['gt_category'].append(x['category'])
          for box in x['bbox']:
            boxes.append(box)
          images_dict['gt_bboxes'].append(boxes)

        return images_dict