#Imports
from PIL import Image, ImageDraw 
import numpy as np

def plot_boxes(image, pred_boxes, pred_class = None, pred_score = None, output_path = None): # Write the required arguments

	# The function should plot the predicted boxes on the images and save them.
	# Tip: keep the dimensions of the output image less than 800 to avoid RAM crashes.
	img = Image.fromarray((np.transpose(image,(1,2,0))*255).astype(np.uint8)) 
	draw = ImageDraw.Draw(img)
	if len(pred_boxes) <= 5:
		for box, text in zip(pred_boxes, pred_class):
			draw.rectangle(box)
			draw.text(box[0], text, fill = "red")
		img.save(output_path)
	else:
		for x in range(5):
			index = pred_score.index(max(pred_score))
			draw.rectangle(pred_boxes[index])
			draw.text(pred_boxes[index][0], pred_class[index], fill = "red")
			pred_score[index] = -1
		img.save(output_path)
	img.show()
	arr = np.asarray(img)
	return arr
'''
img = Image.open(r"/home/ishan/Desktop/SE Lab/CS29006_SW_Lab_Spr2021-main/Python_DS_Assignment/AssignmentQs2/data/imgs/1.jpg")
with open("/home/ishan/Desktop/SE Lab/CS29006_SW_Lab_Spr2021-main/Python_DS_Assignment/AssignmentQs2/data/annotations.jsonl",'r') as f:
            json_list = list(f)
annot = json_list[1]
annot_dict = eval(annot)
pred_boxes = []
for x in annot_dict['bboxes']:
    boxes = []
    for box in x['bbox']:
        boxes.append(box)
    pred_boxes.append(boxes)
print(pred_boxes)
pred_boxes = [[(44.484333, 0.0), (545.2394, 633.6197)], [(79.33754, 249.45157), (535.67004, 566.18134)]]
pred_class = ['cat', 'cat']
pred_score = [0.1, 0.2]
plot_boxes(np.asarray(img), pred_boxes, pred_class, pred_score)
'''