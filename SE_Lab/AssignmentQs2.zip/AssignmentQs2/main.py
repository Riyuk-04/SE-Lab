#Imports
from my_package.model import ObjectDetectionModel
from my_package.data import Dataset
from my_package.analysis.visualize import plot_boxes
from my_package.data import FlipImage, RescaleImage, BlurImage, CropImage, RotateImage

def experiment(annotation_file, detector, transforms, outputs):
    '''
        Function to perform the desired experiments

        Arguments:
        annotation_file: Path to annotation file
        detector: The object detector
        transforms: List of transformation classes
        outputs: path of the output folder to store the images
    '''

    #Create the instance of the dataset.
    data = Dataset(annotation_file, transforms)

    #Iterate over all data items.

    for i in range(len(data)):
        image = data[i]['image']

        #Get the predictions from the detector.
        pred_boxes, pred_class, pred_score = detector(image)

        #Draw the boxes on the image and save them.
        plot_boxes(image, pred_boxes, pred_class, pred_score, outputs+str(i)+".png")


    #Do the required analysis experiments.
    
    outputs = "analysis/"
    image = data[2]['image']


    image = data[2]['image']
    pred_boxes, pred_class, pred_score = detector(image)
    plot_boxes(image, pred_boxes, pred_class, pred_score, outputs+"Original.png")

    data = Dataset(annotation_file, [FlipImage()])
    image = data[2]['image']
    pred_boxes, pred_class, pred_score = detector(image)
    plot_boxes(image, pred_boxes, pred_class, pred_score, outputs+"Flip.png")

    data = Dataset(annotation_file, [BlurImage(2)])
    image = data[2]['image']
    pred_boxes, pred_class, pred_score = detector(image)
    plot_boxes(image, pred_boxes, pred_class, pred_score, outputs+"Blur.png")
    
    data = Dataset(annotation_file, [RescaleImage((2*image.shape[2], 2*image.shape[1]))])
    image = data[2]['image']
    pred_boxes, pred_class, pred_score = detector(image)
    plot_boxes(image, pred_boxes, pred_class, pred_score, outputs+"2X.png")

    data = Dataset(annotation_file, [RescaleImage((image.shape[2]//2, image.shape[1]//2))])
    image = data[2]['image']
    pred_boxes, pred_class, pred_score = detector(image)
    plot_boxes(image, pred_boxes, pred_class, pred_score, outputs+"0.5X.png")

    data = Dataset(annotation_file, [RotateImage(-90)])
    image = data[2]['image']
    pred_boxes, pred_class, pred_score = detector(image)
    plot_boxes(image, pred_boxes, pred_class, pred_score, outputs+"90Right.png")

    data = Dataset(annotation_file, [RotateImage(45)])
    image = data[2]['image']
    pred_boxes, pred_class, pred_score = detector(image)
    plot_boxes(image, pred_boxes, pred_class, pred_score, outputs+"45Left.png")

def main():
    detector = ObjectDetectionModel()
    experiment('./data/annotations.jsonl', detector, [FlipImage(), BlurImage()], "outputs/") # Sample arguments to call experiment()



if __name__ == '__main__':
    main()